import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { Transaction } from '../transaction';

@Component({
  selector: 'app-deposite',
  templateUrl: './deposite.component.html',
  styleUrls: ['./deposite.component.css']
})
export class DepositeComponent implements OnInit {

  bankService: BankService;
  transaction: Transaction;

  constructor(bankService: BankService) {
    this.bankService = bankService;
   }

  depositeBalance(data: any){
  let transId = Math.floor(Math.random()*100) + 10;
  this.transaction = new Transaction(transId,"Deposite",data.depbalance,data.depaccountno);  
  this.bankService.depositeBalance(data, this.transaction);
  }
  ngOnInit() {
  }

}
