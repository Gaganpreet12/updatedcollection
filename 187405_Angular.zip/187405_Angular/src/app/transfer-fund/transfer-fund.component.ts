import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { Transaction } from '../transaction';

@Component({
  selector: 'app-transfer-fund',
  templateUrl: './transfer-fund.component.html',
  styleUrls: ['./transfer-fund.component.css']
})
export class TransferFundComponent implements OnInit {

  bankService: BankService;
  transaction: Transaction;
  transaction1: Transaction;

  constructor(bankService: BankService) {
    this.bankService = bankService;
   }


  transferBalance(data:any){
    let transId = Math.floor(Math.random() * 100) + 10;
    let transId1 = Math.floor(Math.random() * 100) + 10;
    this.transaction = new Transaction(transId, "Transfer Money", data.transferbalance, data.fromaccountno);
    this.transaction1 = new Transaction(transId1, "Recieve Money", data.transferbalance, data.toaccountno);
    this.bankService.transferBalance(data, this.transaction, this.transaction1);
    
  
  }

  ngOnInit() {
  }

}
