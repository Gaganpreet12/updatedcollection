package com.cg.collection.exceptions;

public class LessDepositException extends Exception{

	@Override
	public String toString() {

		return "Amount should be greater than 0";
	}

	public LessDepositException() {

	}
}
