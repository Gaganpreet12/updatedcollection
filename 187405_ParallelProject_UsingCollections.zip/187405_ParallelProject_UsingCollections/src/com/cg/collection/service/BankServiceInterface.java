package com.cg.collection.service;

import com.cg.collection.exceptions.AccountAlreadyExistsException;
import com.cg.collection.exceptions.AccountNotFoundException;
import com.cg.collection.exceptions.LessDepositException;
import com.cg.collection.exceptions.LowBalanceException;

public interface BankServiceInterface {

	public boolean createAccount(String name, String add, long accNum, String phoneNum, int pin, int balance)
			throws AccountAlreadyExistsException;

	public int showBalance(long accNum) throws AccountNotFoundException;

	public int deposit(long accNum, int depositAmount) throws AccountNotFoundException, LessDepositException;

	public int withdraw(long accNum, int withdrawAmount) throws AccountNotFoundException, LowBalanceException, LessDepositException;

	public boolean transferfund(long accNum, long accNum1, int transferAmount)
			throws AccountNotFoundException, LowBalanceException, LessDepositException;

	public boolean validateBalance(long accNum, int amount) throws LowBalanceException;

	public String setTrans(long accNum) throws AccountNotFoundException;

}
