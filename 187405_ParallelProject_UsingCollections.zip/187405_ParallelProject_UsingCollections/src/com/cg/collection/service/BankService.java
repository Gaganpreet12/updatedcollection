package com.cg.collection.service;

import com.cg.collection.bean.BankBean;
import com.cg.collection.dao.BankDao;
import com.cg.collection.dao.BankDaoInterface;
import com.cg.collection.exceptions.*;

public class BankService implements BankServiceInterface {

	BankDaoInterface daoObj = new BankDao();
	BankBean bankObj = new BankBean();
	BankBean bank1 = new BankBean();

	// boolean result;

	// to get the details if account exists or not and add account

	public boolean createAccount(String name, String add, long accNum, String phoneNum, int pinNum, int balance)
			throws AccountAlreadyExistsException {

		BankBean beanObj = new BankBean();
		boolean result = false;

		if (daoObj.checkAccount(accNum) == null) {

			beanObj.setAccNumber(accNum);
			beanObj.setAddRes(add);
			beanObj.setBalance(balance);
			beanObj.setuserName(name);
			beanObj.setPhoneNumber(phoneNum);
			beanObj.setPin(pinNum);
			beanObj.setTrans("Account Created with Balance  : " + balance + "\n");

			daoObj.setData(accNum, beanObj);

			result = true;
		}

		else

		{
			result = false;
			throw new AccountAlreadyExistsException();
		}
		return result;

	}

	// to show balance

	public int showBalance(long accNum) throws AccountNotFoundException {

		bankObj = daoObj.checkAccount(accNum);
		int balance = 0;
		if (bankObj == null) {
			throw new AccountNotFoundException();
		} else {
			balance = bankObj.getBalance();
		}

		return balance;
	}

	// to deposit

	public int deposit(long accNum, int depositAmount) throws AccountNotFoundException, LessDepositException {

		int balance = 0;
		int flag=0;
		try {
		bankObj = daoObj.checkAccount(accNum);

		if (bankObj == null) {
			flag=1;
			throw new AccountNotFoundException();
		} else {
			if (depositAmount <= 0) {
				throw new LessDepositException();
			} else {
				balance = bankObj.setBalance(bankObj.getBalance() + depositAmount);
				if(flag==0) {
				String s = bankObj.getTrans() + "Amount deposited :" + depositAmount + "\n";
				bankObj.setTrans(s);
				daoObj.setData(accNum, bankObj);
				}
			}

		}

		
		}catch(LessDepositException le){
			System.out.println(le);
		}
		return balance;
	}

	// to withdraw

	public int withdraw(long accNo, int withdrawAmount) throws AccountNotFoundException, LowBalanceException, LessDepositException {

		int balance = 0;
		bankObj = daoObj.checkAccount(accNo);
		if (bankObj == null) {
			throw new AccountNotFoundException();
		} else {
			if(withdrawAmount<=0){
				throw new LessDepositException();
				
			}
			else if (bankObj.getBalance() > withdrawAmount) {
				balance = bankObj.setBalance(bankObj.getBalance() - withdrawAmount);
				String s = bankObj.getTrans() + "Amount withdrawn :" + withdrawAmount + "\n";
				bankObj.setTrans(s);
			} else {
				throw new LowBalanceException();
			}
			daoObj.setData(accNo, bankObj);
		}

		return balance;
	}

	// to transfer fund

	public boolean transferfund(long accNum, long accNum1, int transferAmount)
			throws AccountNotFoundException, LowBalanceException, LessDepositException {

		bankObj = daoObj.checkAccount(accNum);

		if (!(bankObj == null)) {

			bank1 = daoObj.checkAccount(accNum1);

			if (!(bank1 == null))

			{

				int sender_balance = bankObj.getBalance();
				if(transferAmount<=0) {
					throw new LessDepositException();
				}
				else if (sender_balance > transferAmount) {
					int reciever_balance = bank1.getBalance();

					bankObj.setBalance(sender_balance - transferAmount);
					bank1.setBalance(reciever_balance + transferAmount);
					String s = bankObj.getTrans() + "Transferred to  :" + accNum1 + " Amount : " + transferAmount
							+ "\n";
					bankObj.setTrans(s);
					String s1 = bank1.getTrans() + "Transferred from  :" + accNum1 + " Amount : " + transferAmount
							+ "\n";
					bank1.setTrans(s1);
					daoObj.setData(accNum, bankObj);
					daoObj.setData(accNum1, bank1);
				} else {
					throw new LowBalanceException();
				}
			}

			else {
				throw new AccountNotFoundException();
			}
		} else {
			throw new AccountNotFoundException();
		}

		return true;
	}

	// to validate Balance

	public boolean validateBalance(long accNum, int amount) throws LowBalanceException

	{
		bankObj = daoObj.checkAccount(accNum);
		if (bankObj == null) {
			throw new LowBalanceException();
		} else {
			return true;
		}
	}

	// to set transactions

	public String setTrans(long accNo) throws AccountNotFoundException {

		bankObj = daoObj.checkAccount(accNo);
		String s;

		if (bankObj == null) {
			throw new AccountNotFoundException();
		} else {
			s = bankObj.getTrans();
		}
		return s;
	}

}
